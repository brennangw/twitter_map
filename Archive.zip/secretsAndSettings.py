twitterKeys = {
'consumer_key': "cP2lSdZLaN3pK8GIisjGEz5Fi",
'consumer_secret': "LC7zCHcQkaJ418CHwV3bof4hWLbD2jtaz9965LNqmBQ7GcBII9",
'access_token': "835005557442555904-IJ5hZg7KVZBmRDkPMFuk3domtd6su15",
'access_token_secret': "CcgtW6STNmYodJMuy2jAMRN4VrAzdQ8QMLQKjQubKVthn"
}

elasticSearch = {
    'uri': "http://search-cc1-elrszc62zf4twlepdkvliqzvpa.us-east-1.es.amazonaws.com",
    'port': 443,
    'use_ssl': True
}